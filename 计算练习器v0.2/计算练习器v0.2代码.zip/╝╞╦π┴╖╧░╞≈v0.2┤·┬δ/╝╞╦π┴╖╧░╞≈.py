import Calculation_process
print("1.正常乘法计算")
print("2.正常加法计算")
print("3.圆周率计算")
print("现在仅有三种，后期会进行更新！！！！！！,若不想继续直接关闭窗口即可")
print("ps:此程序还有很多不完善的地方，后期会进行修改可以关注我的个人网站:http://66666.eu5.org/")
pattern=int(input("请输入上方其中一种模式的编号："))
if pattern==1:
    print("已进入第一种模式，现在开始进行计算练习")
    Calculation_process.multiplication()
elif pattern==2:
    print("已进入第二种模式，现在开始进行计算练习")
    Calculation_process.addition()
elif pattern==3:
    print("已进入第三种模式，现在开始进行计算练习")
    Calculation_process.PI()
