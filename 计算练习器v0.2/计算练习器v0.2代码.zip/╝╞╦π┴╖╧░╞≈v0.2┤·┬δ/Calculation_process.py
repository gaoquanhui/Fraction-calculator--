import random
#乘法计算
def multiplication():
    while True:
        factor1=random.randint(1,100) #取值因数1
        factor2 = random.randint(1, 100) #取值因数2
        product=factor1*factor2
        symbol="*"
        print(factor1,symbol,factor2)
        Input_product=int(input("请输入得数：")) #输入结果
        #判断结果
        if Input_product==product:
            print("恭喜你答对了！！！！！！！！！天才！！！！！！(๑•̀ㅂ•́)و✧")
        else:
            print("答错了，下次努力！！！！！(＞﹏＜)")
#加法计算
def addition():
    while True:
        addend1=random.randint(1,1000)  #取值加数1
        addend2 = random.randint(1, 1000)  #取值加数2
        sum=addend1+addend2
        symbol2="+"
        print(addend1,symbol2,addend2)
        input_sum=int(input("请输入得数："))
        #判断结果
        if input_sum==sum:
            print("恭喜你答对了！！！！！！！！！天才！！！！！！(๑•̀ㅂ•́)و✧")
        else:
            print("答错了，下次努力！！！！！(＞﹏＜)")
#圆周率
def PI():
    while True:
        pi=3.14
        Another_number=random.randint(1, 100)
        Get_the_number=pi*Another_number
        The_final_result=round(Get_the_number,2)
        symbol3="*"
        #print(Get_the_number)
        print(pi,symbol3,Another_number)
        input_Get_the_number=float(input("请输入得数："))
        if input_Get_the_number==The_final_result:
            print("恭喜你答对了！！！！！！！！！天才！！！！！！(๑•̀ㅂ•́)و✧")
        else:
            print("答错了，下次努力！！！！！(＞﹏＜)")